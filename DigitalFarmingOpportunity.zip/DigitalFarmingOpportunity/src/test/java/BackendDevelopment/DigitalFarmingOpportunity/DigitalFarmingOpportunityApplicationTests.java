package BackendDevelopment.DigitalFarmingOpportunity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalFarmingOpportunityApplicationTests {

	@Test
	void contextLoads() {
	}

}
